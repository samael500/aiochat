A module for making nose pretty using colors.


