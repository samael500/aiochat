import unittest


class TC(unittest.TestCase):
    def runTest(self):  # noqa
        raise ValueError("I hate fancy stuff")
