import logging

logger = logging.getLogger('aioredis')
